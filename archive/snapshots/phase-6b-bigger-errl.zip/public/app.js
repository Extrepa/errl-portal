// ===== Canvas Particle Field =====
const canvas = document.getElementById("bgParticles");
const ctx = canvas.getContext("2d");

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  const glCanvas = document.getElementById("errlWebGL");
  if (glCanvas) {
    glCanvas.width = window.innerWidth;
    glCanvas.height = window.innerHeight;
  }
}
resizeCanvas();
window.addEventListener("resize", resizeCanvas);

// Tunables controlled by panel
let particleSpeedScale = 1.0;
let particleAlpha = 0.9;
let particleDensityScale = 1.0;

let BASE_PARTICLE_COUNT = (window.innerWidth * window.innerHeight < 800*800) ? 120 : 200;
let particles = [];

function initParticles() {
  const count = Math.floor(BASE_PARTICLE_COUNT * particleDensityScale);
  particles = Array.from({ length: count }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    vx: (Math.random() - 0.5) * 0.2,
    vy: (Math.random() - 0.5) * 0.2,
    r: 1.5 + Math.random() * 2.5,
  }));
}
initParticles();

function drawParticles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (const p of particles) {
    p.x += p.vx * particleSpeedScale;
    p.y += p.vy * particleSpeedScale;

    // wrap
    if (p.x < 0) p.x += canvas.width;
    if (p.x > canvas.width) p.x -= canvas.width;
    if (p.y < 0) p.y += canvas.height;
    if (p.y > canvas.height) p.y -= canvas.height;

    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(130,160,255,${particleAlpha})`;
    ctx.shadowColor = "rgba(130,160,255,1)";
    ctx.shadowBlur = 12;
    ctx.fill();
  }

  requestAnimationFrame(drawParticles);
}
drawParticles();

// Burst button spawns a quick swarm
function burstParticles() {
  for (let i = 0; i < 40; i++) {
    particles.push({
      x: canvas.width / 2,
      y: canvas.height / 2,
      vx: (Math.random() - 0.5) * 1.5,
      vy: (Math.random() - 0.5) * 1.5,
      r: 2 + Math.random() * 3,
    });
  }
  // let them slowly fade out
  setTimeout(() => {
    particles.splice(BASE_PARTICLE_COUNT);
  }, 800);
}


// ===== Orbiting Menu Bubbles around Errl =====
const bubbles = [...document.querySelectorAll(".bubble")];
// index bubbles for GL sync
bubbles.forEach((b, i) => b.dataset.orbIndex = String(i));
const errl = document.getElementById("errl");

// Nav orbit controls
let navOrbitSpeed = 1.0; // 0..2
let navRadiusScale = 1.0; // 0.6..1.6

function updateBubbles(t) {
  const rect = errl.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;

  bubbles.forEach((b, i) => {
    const baseAngle = parseFloat(b.dataset.angle);
    const dist = parseFloat(b.dataset.dist) * navRadiusScale;

    // orbit: direction alternates per bubble
    const angleDeg = baseAngle + (t * 0.00003 * navOrbitSpeed * (i % 2 === 0 ? 1 : -1)) * 360;
    const rad = (angleDeg * Math.PI) / 180;

    const x = cx + Math.cos(rad) * dist;
    const y = cy + Math.sin(rad) * dist;

    b.style.left = x + "px";
    b.style.top = y + "px";
    b.style.transform = "translate(-50%, -50%)";
  });

  // notify GL layer to sync orb positions
  if (window.errlGLSyncOrbs) window.errlGLSyncOrbs();
  requestAnimationFrame(updateBubbles);
}
requestAnimationFrame(updateBubbles);

// hover -> GL orb squish
bubbles.forEach(b => {
  b.addEventListener('mouseenter', () => { if (window.errlGLOrbHover) window.errlGLOrbHover(+b.dataset.orbIndex, true); });
  b.addEventListener('mouseleave', () => { if (window.errlGLOrbHover) window.errlGLOrbHover(+b.dataset.orbIndex, false); });
});


// ===== Aura / goo color shift driven by panel sliders =====
const auraEl = document.getElementById("errlGoo");
const auraPulseSlider = document.getElementById("auraPulse");
const auraHueSlider = document.getElementById("auraHue");

function updateAura() {
  const hue = auraHueSlider.value; // 0-360
  const pulse = parseFloat(auraPulseSlider.value); // 0-1

  auraEl.style.background =
    `radial-gradient(circle at 50% 30%,\n      hsla(${hue},100%,60%,${0.3 + pulse * 0.6}) 0%,\n      rgba(0,0,0,0) 70%)`;

  // scale the animation speed for gooPulse via playbackRate hack
  const gooAnim = auraEl.getAnimations()[0];
  if (gooAnim) {
    gooAnim.playbackRate = 0.5 + pulse * 1.5;
  }
}

// Hook slider changes
[auraPulseSlider, auraHueSlider].forEach(slider => {
  slider.addEventListener("input", updateAura);
});
updateAura();


// ===== Panel -> particles & nav bindings =====
const bgSpeed = document.getElementById("bgSpeed");
const bgDensity = document.getElementById("bgDensity");
const bgAlpha = document.getElementById("bgAlpha");
const navOrbitSpeedEl = document.getElementById('navOrbitSpeed');
const navRadiusEl = document.getElementById('navRadius');
const glOrbsToggle = document.getElementById('glOrbsToggle');
const rotateSkinsBtn = document.getElementById('rotateSkins');

bgSpeed.addEventListener("input", () => {
  particleSpeedScale = parseFloat(bgSpeed.value);
  if (window.errlGLSetBubbles) window.errlGLSetBubbles({ speed: particleSpeedScale });
});

bgDensity.addEventListener("input", () => {
  particleDensityScale = parseFloat(bgDensity.value);
  initParticles();
  if (window.errlGLSetBubbles) window.errlGLSetBubbles({ density: particleDensityScale });
});

bgAlpha.addEventListener("input", () => {
  particleAlpha = parseFloat(bgAlpha.value);
  if (window.errlGLSetBubbles) window.errlGLSetBubbles({ alpha: particleAlpha });
});

navOrbitSpeedEl && navOrbitSpeedEl.addEventListener('input', ()=>{
  navOrbitSpeed = parseFloat(navOrbitSpeedEl.value);
});
navRadiusEl && navRadiusEl.addEventListener('input', ()=>{
  navRadiusScale = parseFloat(navRadiusEl.value);
});

glOrbsToggle && glOrbsToggle.addEventListener('change', ()=>{
  if (window.errlGLShowOrbs) window.errlGLShowOrbs(glOrbsToggle.checked);
});

// Texture skins for nav bubbles
(function(){
  const NAV_SKINS = [
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-1.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-2.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-3.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-4.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-5.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-6.png'
  ];
  function assignSkins(start){
    for (let i=0;i<bubbles.length;i++){
      const url = NAV_SKINS[(start+i)%NAV_SKINS.length];
      const b = bubbles[i];
      b.style.backgroundImage = `url("${url}")`;
      b.style.backgroundPosition = 'center';
      b.style.backgroundRepeat = 'no-repeat';
      b.style.backgroundSize = '120%';
    }
  }
  let start = +(localStorage.getItem('nav_skin_idx')||0);
  assignSkins(start);
  rotateSkinsBtn && rotateSkinsBtn.addEventListener('click', ()=>{
    start = (start+1) % 6; localStorage.setItem('nav_skin_idx', String(start)); assignSkins(start);
  });
})();

document.getElementById("burstBtn").addEventListener("click", () => {
  if (document.body.dataset.errlMode === 'errl' && window.errlGLBurst) {
    window.errlGLBurst();
  } else {
    burstParticles();
  }
});

// snapshot

document.getElementById("snapshotBtn").addEventListener("click", () => {
  try {
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `errl-bg-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch (e) {
    console.warn("Snapshot failed", e);
  }
});

// ===== Mode toggle buttons =====
const modeStable = document.getElementById("modeStable");
const modeErrl   = document.getElementById("modeErrl");

function webglSupported(){
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl') || c.getContext('experimental-webgl'));
  } catch { return false; }
}

modeStable.addEventListener("click", () => {
  document.body.dataset.errlMode = "stable";
  if (window.disableErrlGL) window.disableErrlGL();
  localStorage.setItem('errlMode','stable');
});
modeErrl.addEventListener("click", () => {
  if (!webglSupported()) return; // no-op if unsupported
  document.body.dataset.errlMode = "errl";
  if (window.enableErrlGL) window.enableErrlGL();
  localStorage.setItem('errlMode','errl');
});

// disable Errl button if no WebGL
if (!webglSupported()) {
  const btn = document.getElementById('modeErrl');
  if (btn) { btn.disabled = true; btn.title = 'WebGL not supported on this device'; }
}

// mood presets
[...document.querySelectorAll('.moodBtn')].forEach(btn => {
  btn.addEventListener('click', () => {
    const mood = btn.dataset.mood;
    localStorage.setItem('errlMood', mood);
    if (window.errlGLSetMood) window.errlGLSetMood(mood);
  });
});

// Hue controls wiring (if controller present)
(function hueWire(){
  const HT = document.getElementById('hueTarget');
  const H  = document.getElementById('hueShift');
  const S  = document.getElementById('hueSat');
  const I  = document.getElementById('hueInt');
  const E  = document.getElementById('hueEnabled');
  const A  = document.getElementById('hueAnimate');
  function apply(){
    if(!window.ErrlHueController) return;
    window.ErrlHueController.setTarget(HT.value);
    window.ErrlHueController.setHueTemp(parseFloat(H.value), HT.value);
    window.ErrlHueController.setSaturationTemp(parseFloat(S.value), HT.value);
    window.ErrlHueController.setIntensityTemp(parseFloat(I.value), HT.value);
    window.ErrlHueController.setEnabledTemp(E.checked, HT.value);
  }
  HT && HT.addEventListener('change', apply);
  H && H.addEventListener('input', apply);
  S && S.addEventListener('input', apply);
  I && I.addEventListener('input', apply);
  E && E.addEventListener('change', apply);
  A && A.addEventListener('click', ()=>{
    if(!window.ErrlHueController) return;
    window.ErrlHueController.toggleAnimation(1.0, HT.value);
  });
})();

// restore mode + mood
(function restore(){
  const m = localStorage.getItem('errlMode');
  if (m === 'errl') { modeErrl.click(); }
  const mood = localStorage.getItem('errlMood');
  if (mood && window.errlGLSetMood) window.errlGLSetMood(mood);
})();
