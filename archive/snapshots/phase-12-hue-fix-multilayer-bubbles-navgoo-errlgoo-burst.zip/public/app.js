// ===== Canvas Particle Field =====
const canvas = document.getElementById("bgParticles");
const ctx = canvas.getContext("2d");

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  const glCanvas = document.getElementById("errlWebGL");
  if (glCanvas) {
    glCanvas.width = window.innerWidth;
    glCanvas.height = window.innerHeight;
  }
}
resizeCanvas();
window.addEventListener("resize", resizeCanvas);

// Tunables controlled by panel
let particleSpeedScale = 1.0;
let particleAlpha = 0.9;
let particleDensityScale = 1.0;

let BASE_PARTICLE_COUNT = (window.innerWidth * window.innerHeight < 800*800) ? 120 : 200;
let particles = [];

function initParticles() {
  const count = Math.floor(BASE_PARTICLE_COUNT * particleDensityScale);
  particles = Array.from({ length: count }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    vx: (Math.random() - 0.5) * 0.2,
    vy: (Math.random() - 0.5) * 0.2,
    r: 1.5 + Math.random() * 2.5,
  }));
}
initParticles();

function drawParticles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (const p of particles) {
    p.x += p.vx * particleSpeedScale;
    p.y += p.vy * particleSpeedScale;

    // wrap
    if (p.x < 0) p.x += canvas.width;
    if (p.x > canvas.width) p.x -= canvas.width;
    if (p.y < 0) p.y += canvas.height;
    if (p.y > canvas.height) p.y -= canvas.height;

    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(130,160,255,${particleAlpha})`;
    ctx.shadowColor = "rgba(130,160,255,1)";
    ctx.shadowBlur = 12;
    ctx.fill();
  }

  requestAnimationFrame(drawParticles);
}
drawParticles();

// Burst button spawns a quick swarm
function burstParticles() {
  const N = 220; // bigger burst
  for (let i = 0; i < N; i++) {
    particles.push({
      x: canvas.width / 2,
      y: canvas.height / 2,
      vx: (Math.random() - 0.5) * 3.2,
      vy: (Math.random() - 0.5) * 3.2,
      r: 2 + Math.random() * 3,
    });
  }
  // let them slowly fade out
  setTimeout(() => {
    particles.splice(BASE_PARTICLE_COUNT);
  }, 1100);
}


// ===== Orbiting Menu Bubbles around Errl =====
const navOrbit = document.getElementById('navOrbit');
const bubbles = [...(navOrbit ? navOrbit.querySelectorAll('.bubble') : document.querySelectorAll('.bubble'))];
// index bubbles for GL sync
bubbles.forEach((b, i) => b.dataset.orbIndex = String(i));
const errl = document.getElementById("errl");

// Nav orbit controls
let navOrbitSpeed = 1.0; // 0..2
let navRadiusScale = 1.0; // 0.6..1.6

function updateBubbles(t) {
  const rect = errl.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;

  bubbles.forEach((b, i) => {
    const baseAngle = parseFloat(b.dataset.angle);
    const dist = parseFloat(b.dataset.dist) * navRadiusScale;

    // orbit: direction alternates per bubble
    const angleDeg = baseAngle + (t * 0.00003 * navOrbitSpeed * (i % 2 === 0 ? 1 : -1)) * 360;
    const rad = (angleDeg * Math.PI) / 180;

    const x = cx + Math.cos(rad) * dist;
    const y = cy + Math.sin(rad) * dist;

    b.style.left = x + "px";
    b.style.top = y + "px";
    b.style.transform = "translate(-50%, -50%)";
  });

  // notify GL layer to sync orb positions
  if (window.errlGLSyncOrbs) window.errlGLSyncOrbs();
  requestAnimationFrame(updateBubbles);
}
requestAnimationFrame(updateBubbles);

// hover -> GL orb squish
bubbles.forEach(b => {
  b.addEventListener('mouseenter', () => { if (window.errlGLOrbHover) window.errlGLOrbHover(+b.dataset.orbIndex, true); });
  b.addEventListener('mouseleave', () => { if (window.errlGLOrbHover) window.errlGLOrbHover(+b.dataset.orbIndex, false); });
});


// ===== Aura / goo color shift driven by panel sliders =====
const auraEl = document.getElementById("errlGoo");
const auraPulseSlider = document.getElementById("auraPulse");
const auraHueSlider = document.getElementById("auraHue");

function updateAura() {
  const hue = auraHueSlider.value; // 0-360
  const pulse = parseFloat(auraPulseSlider.value); // 0-1

  auraEl.style.background =
    `radial-gradient(circle at 50% 30%,\n      hsla(${hue},100%,60%,${0.3 + pulse * 0.6}) 0%,\n      rgba(0,0,0,0) 70%)`;

  // scale the animation speed for gooPulse via playbackRate hack
  const gooAnim = auraEl.getAnimations()[0];
  if (gooAnim) {
    gooAnim.playbackRate = 0.5 + pulse * 1.5;
  }
}

// Hook slider changes
[auraPulseSlider, auraHueSlider].forEach(slider => {
  slider.addEventListener("input", updateAura);
});
updateAura();


// ===== Panel -> particles & nav bindings =====
const bgSpeed = document.getElementById("bgSpeed");
const bgDensity = document.getElementById("bgDensity");
const bgAlpha = document.getElementById("bgAlpha");
const navOrbitSpeedEl = document.getElementById('navOrbitSpeed');
const navRadiusEl = document.getElementById('navRadius');
const glOrbsToggle = document.getElementById('glOrbsToggle');
const rotateSkinsBtn = document.getElementById('rotateSkins');
const glAlphaEl = document.getElementById('glAlpha');
const glDXEl = document.getElementById('glDX');
const glDYEl = document.getElementById('glDY');
// BG bubbles advanced controls
const bubWobble = document.getElementById('bubWobble');
const bubFreq   = document.getElementById('bubFreq');
const bubMin    = document.getElementById('bubMin');
const bubMax    = document.getElementById('bubMax');
const bubFar    = document.getElementById('bubFar');
const bubSizeHz = document.getElementById('bubSizeHz');
const bubJumboPct = document.getElementById('bubJumboPct');
const bubJumboScale = document.getElementById('bubJumboScale');
const bubTexSel = document.getElementById('bubTex');
const bubApplyTex = document.getElementById('bubApplyTex');
const bubUpload = document.getElementById('bubUpload');
const bubUploadBtn = document.getElementById('bubUploadBtn');
const bubPresetSel = document.getElementById('bubPresetSel');
const bubPresetSave = document.getElementById('bubPresetSave');
const bubPresetApply = document.getElementById('bubPresetApply');

bgSpeed.addEventListener("input", () => {
  particleSpeedScale = parseFloat(bgSpeed.value);
  if (window.errlGLSetBubbles) window.errlGLSetBubbles({ speed: particleSpeedScale });
});

bgDensity.addEventListener("input", () => {
  particleDensityScale = parseFloat(bgDensity.value);
  initParticles();
  if (window.errlGLSetBubbles) window.errlGLSetBubbles({ density: particleDensityScale });
});

bgAlpha.addEventListener("input", () => {
  particleAlpha = parseFloat(bgAlpha.value);
  if (window.errlGLSetBubbles) window.errlGLSetBubbles({ alpha: particleAlpha });
});

navOrbitSpeedEl && navOrbitSpeedEl.addEventListener('input', ()=>{
  navOrbitSpeed = parseFloat(navOrbitSpeedEl.value);
});
navRadiusEl && navRadiusEl.addEventListener('input', ()=>{
  navRadiusScale = parseFloat(navRadiusEl.value);
});

glOrbsToggle && glOrbsToggle.addEventListener('change', ()=>{
  if (window.errlGLShowOrbs) window.errlGLShowOrbs(glOrbsToggle.checked);
});

// Texture skins for nav bubbles
(function(){
  const NAV_SKINS = [
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-1.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-2.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-3.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-4.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-5.png',
    '../src/assets/Bubbles_ErrlSiteDecor/Bubbles-6.png'
  ];
  function assignSkins(start){
    for (let i=0;i<bubbles.length;i++){
      const url = NAV_SKINS[(start+i)%NAV_SKINS.length];
      const b = bubbles[i];
      b.style.backgroundImage = `url("${url}")`;
      b.style.backgroundPosition = 'center';
      b.style.backgroundRepeat = 'no-repeat';
      b.style.backgroundSize = '120%';
    }
  }
  let start = +(localStorage.getItem('nav_skin_idx')||0);
  assignSkins(start);
rotateSkinsBtn && rotateSkinsBtn.addEventListener('click', ()=>{
    start = (start+1) % 6; localStorage.setItem('nav_skin_idx', String(start)); assignSkins(start);
  });
})();

// Mood state machine
(function moods(){
  const defs = {
    calm:    { overlay:{alpha:0.18, dx:16, dy:12}, orbit:0.8, particles:0.6, hue:{layer:'backGlow', hue:200, sat:1.0, inten:0.8} },
    curious: { overlay:{alpha:0.22, dx:24, dy:16}, orbit:1.1, particles:0.9, hue:{layer:'nav', hue:160, sat:1.1, inten:1.0}, headTilt: 4 },
    excited: { overlay:{alpha:0.26, dx:36, dy:24}, orbit:1.5, particles:1.2, hue:{layer:'glOverlay', hue:25, sat:1.25, inten:1.0} },
    anxious: { overlay:{alpha:0.30, dx:52, dy:34}, orbit:1.9, particles:1.4, hue:{layer:'backGlow', hue:260, sat:0.9, inten:0.9}, jitter:true }
  };
  let current = localStorage.getItem('errlMood2') || 'calm';
  const reduce = document.getElementById('prefReduce') || {checked:false};
  function apply(name){
    const m = defs[name] || defs.calm; current = name; localStorage.setItem('errlMood2', name);
    if (window.errlGLSetOverlay) window.errlGLSetOverlay({ alpha:m.overlay.alpha, dx:m.overlay.dx, dy:m.overlay.dy });
    navOrbitSpeed = m.orbit * (reduce.checked? 0.4 : 1.0);
    particleSpeedScale = m.particles * (reduce.checked? 0.5 : 1.0);
    if (window.ErrlHueController){ const hc = window.ErrlHueController; hc.setTarget(m.hue.layer); hc.setHueTemp(m.hue.hue, m.hue.layer); hc.setSaturationTemp(m.hue.sat, m.hue.layer); hc.setIntensityTemp(m.hue.inten, m.hue.layer); }
    if (window.errlGLSetMood) window.errlGLSetMood(name==='excited'?'neon':(name==='anxious'?'alert':'calm'));
  }
  document.querySelectorAll('.moodBtn2').forEach(b=> b.addEventListener('click', ()=> apply(b.dataset.mood2)));
  window.requestAnimationFrame(()=> apply(current));
})();

// GL overlay bindings
if (glAlphaEl) glAlphaEl.addEventListener('input', ()=>{ if(window.errlGLSetOverlay) window.errlGLSetOverlay({ alpha: parseFloat(glAlphaEl.value) }); });
if (glDXEl) glDXEl.addEventListener('input', ()=>{ if(window.errlGLSetOverlay) window.errlGLSetOverlay({ dx: parseFloat(glDXEl.value) }); });
if (glDYEl) glDYEl.addEventListener('input', ()=>{ if(window.errlGLSetOverlay) window.errlGLSetOverlay({ dy: parseFloat(glDYEl.value) }); });

// BG bubbles advanced bindings
function pushBubblesPatch(){
  if (!window.errlGLSetBubbles) return;
  window.errlGLSetBubbles({
    wobble: bubWobble? parseFloat(bubWobble.value): undefined,
    freq:   bubFreq? parseFloat(bubFreq.value): undefined,
    minSize: bubMin? parseFloat(bubMin.value): undefined,
    maxSize: bubMax? parseFloat(bubMax.value): undefined,
    farRatio: bubFar? parseFloat(bubFar.value): undefined,
    sizeJitterFreq: bubSizeHz? parseFloat(bubSizeHz.value): undefined,
    jumboChance: bubJumboPct? parseFloat(bubJumboPct.value): undefined,
    jumboScale: bubJumboScale? parseFloat(bubJumboScale.value): undefined,
  });
}
[bubWobble,bubFreq,bubMin,bubMax,bubFar,bubSizeHz,bubJumboPct,bubJumboScale].forEach(el=> el && el.addEventListener('input', pushBubblesPatch));

// Texture controls (global)
if (bubUploadBtn && bubUpload) {
  bubUploadBtn.addEventListener('click', ()=> bubUpload.click());
  bubUpload.addEventListener('change', ()=>{
    const f = bubUpload.files && bubUpload.files[0]; if(!f) return;
    const url = URL.createObjectURL(f);
    if (window.errlGLSetBubblesTexture) window.errlGLSetBubblesTexture('custom', url);
  });
}
if (bubApplyTex && bubTexSel) {
  bubApplyTex.addEventListener('click', ()=>{
    const v = bubTexSel.value;
    if (window.errlGLSetBubblesTexture) window.errlGLSetBubblesTexture(v, null);
  });
}
// Per-layer textures
(function texLayers(){
  const defs=[
    {sel:'A', idx:0},
    {sel:'B', idx:1},
    {sel:'C', idx:2},
  ];
  defs.forEach(({sel, idx})=>{
    const S=document.getElementById('bubTex'+sel), A=document.getElementById('bubApplyTex'+sel), U=document.getElementById('bubUpload'+sel), UB=document.getElementById('bubUploadBtn'+sel);
    if(UB && U){ UB.addEventListener('click', ()=> U.click()); U.addEventListener('change', ()=>{ const f=U.files && U.files[0]; if(!f) return; const url=URL.createObjectURL(f); window.errlGLSetBubblesLayerTexture && window.errlGLSetBubblesLayerTexture(idx,'custom',url); }); }
    if(A && S){ A.addEventListener('click', ()=>{ const v=S.value; window.errlGLSetBubblesLayerTexture && window.errlGLSetBubblesLayerTexture(idx, v, null); }); }
  });
})();

// Presets (stored in localStorage)
(function presets(){
  if(!bubPresetSel) return;
  const KEY='errl_bub_presets';
  const builtin={
    Calm:{ speed:0.6, density:0.8, alpha:0.85, wobble:0.6, freq:0.7, minSize:14, maxSize:34, farRatio:0.4, sizeJitterFreq:0.0 },
    Neon:{ speed:1.2, density:1.2, alpha:0.95, wobble:1.3, freq:1.2, minSize:16, maxSize:46, farRatio:0.33, sizeJitterFreq:0.2, jumboChance:0.12, jumboScale:1.7 },
    Dense:{ speed:0.9, density:1.5, alpha:0.9, wobble:1.0, freq:1.0, minSize:12, maxSize:38, farRatio:0.28 },
  };
  function load(){ try{ return Object.assign({}, builtin, JSON.parse(localStorage.getItem(KEY)||'{}')); }catch{ return {...builtin}; } }
  function save(map){ try{ localStorage.setItem(KEY, JSON.stringify(map)); }catch{}
  }
  function fill(){ const map=load(); bubPresetSel.innerHTML=''; Object.keys(map).forEach(name=>{ const o=document.createElement('option'); o.value=name; o.textContent=name; bubPresetSel.appendChild(o); }); }
  function currentParams(){
    return {
      speed: parseFloat(bgSpeed.value), density: parseFloat(bgDensity.value), alpha: parseFloat(bgAlpha.value),
      wobble: parseFloat(bubWobble.value), freq: parseFloat(bubFreq.value),
      minSize: parseFloat(bubMin.value), maxSize: parseFloat(bubMax.value), farRatio: parseFloat(bubFar.value),
      sizeJitterFreq: parseFloat(bubSizeHz.value), jumboChance: parseFloat(bubJumboPct.value), jumboScale: parseFloat(bubJumboScale.value),
    };
  }
  function applyParams(p){
    if('speed' in p){ bgSpeed.value=p.speed; bgSpeed.dispatchEvent(new Event('input')); }
    if('density' in p){ bgDensity.value=p.density; bgDensity.dispatchEvent(new Event('input')); }
    if('alpha' in p){ bgAlpha.value=p.alpha; bgAlpha.dispatchEvent(new Event('input')); }
    if('wobble' in p){ bubWobble.value=p.wobble; }
    if('freq' in p){ bubFreq.value=p.freq; }
    if('minSize' in p){ bubMin.value=p.minSize; }
    if('maxSize' in p){ bubMax.value=p.maxSize; }
    if('farRatio' in p){ bubFar.value=p.farRatio; }
    if('sizeJitterFreq' in p){ bubSizeHz.value=p.sizeJitterFreq; }
    if('jumboChance' in p){ bubJumboPct.value=p.jumboChance; }
    if('jumboScale' in p){ bubJumboScale.value=p.jumboScale; }
    pushBubblesPatch();
  }
  fill();
  bubPresetApply && bubPresetApply.addEventListener('click', ()=>{ const map=load(); const name=bubPresetSel.value; const p=map[name]; if(p) applyParams(p); });
  bubPresetSave && bubPresetSave.addEventListener('click', ()=>{ const name=prompt('Preset name:'); if(!name) return; const map=load(); map[name]=currentParams(); save(map); fill(); bubPresetSel.value=name; });
})();

document.getElementById("burstBtn").addEventListener("click", () => {
  if (document.body.dataset.errlMode === 'errl' && window.errlGLBurst) {
    window.errlGLBurst();
  } else {
    burstParticles();
  }
});

// snapshot

document.getElementById("snapshotBtn").addEventListener("click", () => {
  try {
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `errl-bg-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch (e) {
    console.warn("Snapshot failed", e);
  }
});

// Errl goo controls
(function gooCtrls(){
  const goo=document.getElementById('errlGoo'); if(!goo) return;
  const on=document.getElementById('gooEnabled'); const blur=document.getElementById('gooBlur'); const alpha=document.getElementById('gooAlpha'); const scale=document.getElementById('gooScale');
  function apply(){ goo.style.display = on && on.checked ? 'block' : 'none'; if(blur) goo.style.filter = `blur(${parseInt(blur.value,10)}px)`; if(alpha) goo.style.opacity = String(parseFloat(alpha.value)); if(scale){ const s=parseFloat(scale.value); goo.style.transform = `translate(-50%, -40%) scale(${s}, ${1.1*s})`; } }
  ;[on,blur,alpha,scale].forEach(el=> el && el.addEventListener('input', apply));
  apply();
})();

// ===== Shimmer toggle =====
const shimmerToggle = document.getElementById('shimmerToggle');
if (shimmerToggle) {
  shimmerToggle.addEventListener('change', () => {
    const root = document.querySelector('.errl-bg');
    if (!root && shimmerToggle.checked) {
      if (window.ErrlBG && typeof ErrlBG.mount === 'function') {
        ErrlBG.mount({ headerVariant: 2, shimmer: true, parallax: true, hud: false, basePath: '../src' });
      }
    } else if (root) {
      root.style.display = shimmerToggle.checked ? 'block' : 'none';
    }
  });
}

// ===== Audio engine =====
(function audio(){
  const toggle = document.getElementById('audioEnabled');
  const master = document.getElementById('audioMaster');
  const A = { ctx:null, master:null, sub:null, subGain:null, enabled:false };
  function ensure(){ if(A.ctx) return; const C=window.AudioContext||window.webkitAudioContext; if(!C) return; A.ctx=new C(); A.master=A.ctx.createGain(); A.master.gain.value = parseFloat(master?.value||0.4); A.master.connect(A.ctx.destination);
    // sub drone
    A.sub=A.ctx.createOscillator(); A.sub.type='sine'; A.sub.frequency.value=48; A.subGain=A.ctx.createGain(); A.subGain.gain.value=0.0; A.sub.connect(A.subGain); A.subGain.connect(A.master); A.sub.start();
  }
  function setEnabled(on){ ensure(); A.enabled=on; if(!A.ctx) return; if(on){ A.ctx.resume(); A.subGain.gain.linearRampToValueAtTime(0.08, A.ctx.currentTime+0.3);} else { A.subGain.gain.linearRampToValueAtTime(0.0001, A.ctx.currentTime+0.2);} }
  toggle && toggle.addEventListener('change', ()=> setEnabled(toggle.checked)); master && master.addEventListener('input', ()=>{ ensure(); if(A.master) A.master.gain.value=parseFloat(master.value); });
  // bubble hum on hover
  const active = new Map();
  bubbles.forEach((b,i)=>{
    b.addEventListener('mouseenter', ()=>{ if(!A.enabled) return; ensure(); if(!A.ctx) return; const osc=A.ctx.createOscillator(); osc.type='sine'; const freq=220 + i*30; osc.frequency.value=freq; const g=A.ctx.createGain(); g.gain.value=0.0001; osc.connect(g); g.connect(A.master); osc.start(); g.gain.linearRampToValueAtTime(0.03, A.ctx.currentTime+0.12); active.set(b,{osc,g}); });
    b.addEventListener('mouseleave', ()=>{ const o=active.get(b); if(o){ o.g.gain.linearRampToValueAtTime(0.0001, A.ctx.currentTime+0.1); setTimeout(()=>{ try{ o.osc.stop(); }catch{} },150); active.delete(b);} });
  });
  // tie sub drone to aura pulse
  const pulse = document.getElementById('auraPulse');
  pulse && pulse.addEventListener('input', ()=>{ if(A.sub) A.sub.frequency.value = 40 + parseFloat(pulse.value)*30; });
})();

// ===== Draggable & minimize phone =====
(function phoneDrag(){
  const panel = document.getElementById('errlPanel');
  const header = document.getElementById('errlPhoneHeader');
  const minBtn = document.getElementById('phoneMinToggle');
  if(!panel || !header) return;
  let drag=false, sx=0, sy=0, startL=null, startT=null;
  function toPx(n){ return Math.round(n) + 'px'; }
  function onDown(e){ drag=true; panel.classList.add('dragging'); header.style.cursor='grabbing';
    const r=panel.getBoundingClientRect(); sx=e.clientX; sy=e.clientY; startL=r.left; startT=r.top; panel.style.right='auto'; panel.style.left=toPx(startL); panel.style.top=toPx(startT); }
  function onMove(e){ if(!drag) return; const nx = startL + (e.clientX - sx); const ny = startT + (e.clientY - sy);
    const maxX = window.innerWidth - 120; const maxY = window.innerHeight - 40; panel.style.left = toPx(Math.max(0, Math.min(maxX, nx))); panel.style.top = toPx(Math.max(0, Math.min(maxY, ny))); }
  function onUp(){ if(!drag) return; drag=false; panel.classList.remove('dragging'); header.style.cursor='grab'; }
  header.addEventListener('pointerdown', onDown);
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
  minBtn && minBtn.addEventListener('click', ()=>{ panel.classList.toggle('minimized'); });
})();

// ===== Mode toggle buttons =====
const modeStable = document.getElementById("modeStable");
const modeErrl   = document.getElementById("modeErrl");

function webglSupported(){
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl') || c.getContext('experimental-webgl'));
  } catch { return false; }
}

modeStable.addEventListener("click", () => {
  document.body.dataset.errlMode = "stable";
  if (window.disableErrlGL) window.disableErrlGL();
  localStorage.setItem('errlMode','stable');
});
modeErrl.addEventListener("click", () => {
  if (!webglSupported()) return; // no-op if unsupported
  document.body.dataset.errlMode = "errl";
  if (window.enableErrlGL) window.enableErrlGL();
  localStorage.setItem('errlMode','errl');
});

// disable Errl button if no WebGL
if (!webglSupported()) {
  const btn = document.getElementById('modeErrl');
  if (btn) { btn.disabled = true; btn.title = 'WebGL not supported on this device'; }
}

// mood presets
[...document.querySelectorAll('.moodBtn')].forEach(btn => {
  btn.addEventListener('click', () => {
    const mood = btn.dataset.mood;
    localStorage.setItem('errlMood', mood);
    if (window.errlGLSetMood) window.errlGLSetMood(mood);
  });
});

// Hue controls wiring (if controller present)
(function hueWire(){
  const HT = document.getElementById('hueTarget');
  const H  = document.getElementById('hueShift');
  const S  = document.getElementById('hueSat');
  const I  = document.getElementById('hueInt');
  const E  = document.getElementById('hueEnabled');
  const A  = document.getElementById('hueAnimate');
  function apply(){
    if(!window.ErrlHueController) return;
    window.ErrlHueController.setTarget(HT.value);
    window.ErrlHueController.setHueTemp(parseFloat(H.value), HT.value);
    window.ErrlHueController.setSaturationTemp(parseFloat(S.value), HT.value);
    window.ErrlHueController.setIntensityTemp(parseFloat(I.value), HT.value);
    window.ErrlHueController.setEnabledTemp(E.checked, HT.value);
  }
  HT && HT.addEventListener('change', apply);
  H && H.addEventListener('input', apply);
  S && S.addEventListener('input', apply);
  I && I.addEventListener('input', apply);
  E && E.addEventListener('change', apply);
  A && A.addEventListener('click', ()=>{
    if(!window.ErrlHueController) return;
    window.ErrlHueController.toggleAnimation(1.0, HT.value);
  });
})();

// Tabs
(function tabs(){
  const tabs = document.getElementById('panelTabs');
  if(!tabs) return;
  tabs.addEventListener('click', (e)=>{
    const b = e.target.closest('button[data-tab]'); if(!b) return;
    tabs.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active', t===b));
    const key=b.dataset.tab;
    document.querySelectorAll('.errl-panel .panel-section').forEach(sec=>{
      const tab=sec.getAttribute('data-tab');
      sec.style.display = (!tab || tab===key)? 'block':'none';
    });
  });
  // initialize
  const first=tabs.querySelector('.tab.active')||tabs.querySelector('.tab'); if(first) first.click();
})();

// Nav Goo controls
(function navGoo(){
  const wrap = document.getElementById('navOrbit'); if(!wrap) return;
  const on = document.getElementById('navGooEnabled');
  const blur = document.getElementById('navGooBlur');
  const mult = document.getElementById('navGooMult');
  const thr = document.getElementById('navGooThresh');
  function apply(){
    const enabled = on && on.checked;
    wrap.classList.toggle('goo-on', !!enabled);
    wrap.style.filter = enabled ? 'url(#uiGoo)' : 'none';
    const blurNode = document.getElementById('navGooBlurNode'); if(blurNode && blur) blurNode.setAttribute('stdDeviation', String(parseFloat(blur.value)));
    const mat = document.getElementById('navGooMatrixNode');
    if(mat && mult && thr){ const m = Math.max(1, parseFloat(mult.value)||24); const t = parseFloat(thr.value)||-14; mat.setAttribute('values', `1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 ${m} ${t}`); }
  }
  ;[on,blur,mult,thr].forEach(el=> el && el.addEventListener('input', apply));
  apply();
})();

// Accessibility
(function accessibility(){
  const prefReduce = document.getElementById('prefReduce');
  const prefContrast = document.getElementById('prefContrast');
  function apply(){
    if (prefReduce){ document.body.classList.toggle('reduced-motion', prefReduce.checked); localStorage.setItem('prefReduce', prefReduce.checked?'1':'0'); }
    if (prefContrast){ document.body.classList.toggle('high-contrast', prefContrast.checked); localStorage.setItem('prefContrast', prefContrast.checked?'1':'0'); }
  }
  prefReduce && prefReduce.addEventListener('change', apply);
  prefContrast && prefContrast.addEventListener('change', apply);
  // initialize from storage
  const rm = localStorage.getItem('prefReduce')==='1'; const hc = localStorage.getItem('prefContrast')==='1';
  if (prefReduce) prefReduce.checked = rm; if (prefContrast) prefContrast.checked = hc; apply();
})();

// Device tilt parallax
(function tilt(){
  const layer = document.querySelector('.scene-layer'); if(!layer) return;
  function apply(dx,dy){ layer.style.transform = `translate3d(${dx}px, ${dy}px, 0)`; }
  window.addEventListener('deviceorientation', (e)=>{
    if(e.beta==null && e.gamma==null) return;
    const dx = (e.gamma||0) * 0.4; const dy = (e.beta||0) * -0.2; apply(dx, dy);
  });
})();

// restore mode + mood
(function restore(){
  const m = localStorage.getItem('errlMode');
  if (m === 'errl') { modeErrl.click(); }
  const mood = localStorage.getItem('errlMood');
  if (mood && window.errlGLSetMood) window.errlGLSetMood(mood);
})();
