/* Errl WebGL layer using PixiJS: goo distortion over serialized SVG texture */
(function(){
  const W = window;
  let app = null;
  let sprite = null;
  let filter = null;
  let started = false;
  let paused = true;

  function getCanvas() {
    return document.getElementById('errlWebGL');
  }

  function serializeErrlSVGToURL(size = 512) {
    const svg = document.querySelector('.errl-wrapper svg');
    if (!svg) return null;
    const clone = svg.cloneNode(true);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    clone.setAttribute('width', String(size));
    clone.setAttribute('height', String(size));
    const svgStr = clone.outerHTML;
    const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    return url;
  }

  const vert = `
    precision mediump float;
    attribute vec2 aVertexPosition;
    attribute vec2 aTextureCoord;
    uniform mat3 projectionMatrix;
    varying vec2 vTextureCoord;
    void main(void){
      vTextureCoord = aTextureCoord;
      gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    }
  `;

  const frag = `
    precision mediump float;
    varying vec2 vTextureCoord;
    uniform sampler2D uSampler;
    uniform vec2 uResolution;
    uniform float uTime;
    uniform float uDrip;      // 0-1 how melty
    uniform float uViscosity; // 0-1 smoothing factor
    uniform float uSpeed;     // animation speed multiplier

    float hash(vec2 p){
      return fract(sin(dot(p, vec2(127.1,311.7))) * 43758.5453);
    }
    float noise(vec2 p){
      vec2 i = floor(p); vec2 f = fract(p);
      float a = hash(i);
      float b = hash(i + vec2(1.0,0.0));
      float c = hash(i + vec2(0.0,1.0));
      float d = hash(i + vec2(1.0,1.0));
      vec2 u = f*f*(3.0-2.0*f);
      return mix(a, b, u.x) + (c - a)*u.y*(1.0 - u.x) + (d - b)*u.x*u.y;
    }

    void main(){
      vec2 uv = vTextureCoord;

      // wavy wobble
      float t = uTime * (0.4 + 1.6*uSpeed);
      vec2 n = vec2(
        noise(uv*4.0 + vec2(t*0.12, 0.0)),
        noise(uv*4.0 + vec2(0.0, t*0.15))
      );
      n = (n - 0.5) * 0.06; // amplitude

      // gravity drip bias pulls down near the lower half
      float edge = smoothstep(0.1, 0.9, uv.y);
      float drip = uDrip * (edge);
      uv.y += drip * (0.02 + 0.10*noise(uv*2.0 + vec2(0.0, t*0.2)));

      // viscosity dampens displacement
      uv += n * (1.0 - 0.6*uViscosity);

      vec4 col = texture2D(uSampler, uv);

      // subtle bloom-like lift for bright edges (stroke)
      float lum = dot(col.rgb, vec3(0.299,0.587,0.114));
      col.rgb += smoothstep(0.7, 1.0, lum) * 0.15;

      gl_FragColor = col;
    }
  `;

  function init() {
    if (started) return;
    const view = getCanvas();
    if (!view || !W.PIXI) return;

    app = new PIXI.Application({
      view,
      backgroundAlpha: 0,
      antialias: true,
      autoDensity: true,
      resolution: Math.min(2, W.devicePixelRatio || 1),
      powerPreference: 'high-performance'
    });

    const url = serializeErrlSVGToURL(768);
    if (!url) return;

    const img = new Image();
    img.onload = () => {
      const tex = PIXI.Texture.from(img);
      sprite = new PIXI.Sprite(tex);
      sprite.anchor.set(0.5);
      sprite.x = app.renderer.width / 2;
      sprite.y = app.renderer.height / 2;

      // scale sprite to ~Errl CSS size (~240px box)
      const target = 240;
      const maxDim = Math.max(tex.width, tex.height);
      const s = target / maxDim;
      sprite.scale.set(s);

      filter = new PIXI.Filter(vert, frag, {
        uResolution: new PIXI.Point(app.renderer.width, app.renderer.height),
        uTime: 0,
        uDrip: 0.35,
        uViscosity: 0.5,
        uSpeed: 0.5,
      });
      sprite.filters = [filter];

      app.stage.addChild(sprite);

      app.ticker.add((delta) => {
        if (paused) return;
        if (filter) filter.uniforms.uTime += 0.016 * delta;
      });

      // keep centered/resized
      const onResize = () => {
        view.width = window.innerWidth;
        view.height = window.innerHeight;
        app.renderer.resize(window.innerWidth, window.innerHeight);
        if (sprite) {
          sprite.x = app.renderer.width / 2;
          sprite.y = app.renderer.height / 2;
        }
        if (filter) {
          filter.uniforms.uResolution = new PIXI.Point(app.renderer.width, app.renderer.height);
        }
      };
      window.addEventListener('resize', onResize);

      // hook panel sliders to uniforms
      const auraPulse = document.getElementById('auraPulse');
      if (auraPulse) {
        auraPulse.addEventListener('input', () => {
          const v = parseFloat(auraPulse.value);
          if (filter) {
            filter.uniforms.uSpeed = v;           // faster wobble
            filter.uniforms.uDrip = 0.15 + 0.7*v; // more melty
          }
        });
      }

      started = true;
      enable();
    };
    img.onerror = () => console.warn('Failed to load serialized Errl SVG for WebGL');
    img.src = url;
  }

  function enable(){
    paused = false;
  }
  function disable(){
    paused = true;
  }

  // expose controls
  W.enableErrlGL = function(){ if (!started) init(); else enable(); };
  W.disableErrlGL = function(){ disable(); };
})();
